Name: Yitao Yu
NETID: yyu56
Assignment: Project2
LabSession: TR1650

"I collaborated with Andrew Thankson"